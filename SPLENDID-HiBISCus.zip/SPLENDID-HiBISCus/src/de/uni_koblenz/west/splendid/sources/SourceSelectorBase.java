/*
 * This file is part of RDF Federator.
 * Copyright 2010 Olaf Goerlitz
 * 
 * RDF Federator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * RDF Federator is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with RDF Federator.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * RDF Federator uses libraries from the OpenRDF Sesame Project licensed 
 * under the Aduna BSD-style license. 
 */
package de.uni_koblenz.west.splendid.sources;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.aksw.simba.fedsum.FedSumSourceSelection;
import org.openrdf.query.MalformedQueryException;
import org.openrdf.query.QueryEvaluationException;
import org.openrdf.query.algebra.StatementPattern;
import org.openrdf.repository.RepositoryException;
import org.openrdf.sail.SailException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fluidops.fedx.FedX;
import com.fluidops.fedx.FederationManager;
import com.fluidops.fedx.algebra.StatementSource;
import com.fluidops.fedx.cache.Cache;
import com.fluidops.fedx.structures.Endpoint;

import de.uni_koblenz.west.evaluation.QueryProcessingEval;
import de.uni_koblenz.west.splendid.helpers.OperatorTreePrinter;
import de.uni_koblenz.west.splendid.index.Graph;
import de.uni_koblenz.west.splendid.model.MappedStatementPattern;
import de.uni_koblenz.west.splendid.statistics.RDFStatistics;

/**
 * Basic behavior of a source selector.
 * Aggregates query patterns in groups with same constant values but different
 * variables before the source selection is done.
 * 
 * @author Olaf Goerlitz
 */
public abstract class SourceSelectorBase implements SourceSelector {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SourceSelectorBase.class);
	
	protected RDFStatistics stats;

	/**
	 * Return all sources for the supplied pattern.
	 * 
	 * @param pattern the statement pattern to process.
	 * @return a set of sources.
	 */
	protected abstract Set<Graph> getSources(StatementPattern pattern);
	
	// --------------------------------------------------------------
	
	@Override
	public void initialize() throws SailException {
		if (this.stats == null)
			throw new SailException("need statistics for source selection");
	}
	
	public void setStatistics(RDFStatistics stats) {
		if (stats == null)
			throw new IllegalArgumentException("statistics must not be null");
		this.stats = stats;
	}
	
	/**
	 * Assigns data sources to query patterns.
	 * 
	 * @param patterns the list of patterns to be processed.
	 * @return the list of patterns with data source mappings.
	 */
	public List<MappedStatementPattern> mapSources(List<StatementPattern> patterns) {
		Map<StatementPattern, List<StatementSource>> stmtToSources = new HashMap<StatementPattern, List<StatementSource>> (); 
	    long startTime = System.currentTimeMillis();	
	    FedX fed = FederationManager.getInstance().getFederation();
		List<Endpoint> members = fed.getMembers();
		Cache cache =FederationManager.getInstance().getCache();
		FedSumSourceSelection sourceSelection = new FedSumSourceSelection(members,cache,QueryProcessingEval.strQuery);
		 try {
			stmtToSources = sourceSelection.performSourceSelection(QueryProcessingEval.DNFgrps);
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedQueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (QueryEvaluationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long srcseltime = System.currentTimeMillis()-startTime;
		System.out.println("Source selection  time (ms): "+ srcseltime);
		try {
			QueryProcessingEval.bw.write((int) srcseltime);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   
		
		List<MappedStatementPattern> pMap = new ArrayList<MappedStatementPattern>();
		//int totalTriplePatternSrces = 0 ;
		// group patterns with same constant values but different variables
		//TriplePatternIndex pso = new TriplePatternIndex(patterns);
	       int tpsrces = 0; 
			for (StatementPattern stmt : stmtToSources.keySet()) 
	          {
	        	tpsrces = tpsrces+ stmtToSources.get(stmt).size();
	        	List<StatementSource> lstFedSumSources = stmtToSources.get(stmt);
	        	Set<Graph> lstSplendidSources = new HashSet<Graph>();
	        	for(StatementSource src:lstFedSumSources)
	        	{
	        	   String endPointUrl = "http://"+src.getEndpointID().replace("sparql_", "");
	 		       endPointUrl = endPointUrl.replace("_", "/");
	        		lstSplendidSources.add(new Graph(endPointUrl));
	        	}
//				System.out.println("-----------\n"+stmt);
//				System.out.println(stmtToSources.get(stmt));
	        	pMap.add(new MappedStatementPattern(stmt, lstSplendidSources));
	         }
			System.out.println("Total triple pattern-wise selected sources after step 2 of FedSum: "+tpsrces);
		
		// determine sources for all distinct pattern groups
//		for (List<StatementPattern> patternGroup : pso.getDistinctPatterns()) {
//			
//			// get sources for the first pattern in group (with same constants)
//			StatementPattern firstPattern = patternGroup.get(0);
//			long startT = System.currentTimeMillis();
//			Set<Graph> sources = getSources(firstPattern);
//			QueryProcessingEval.timeElapsed += System.currentTimeMillis()-startT;
//			// print warning if no sources were found
//			if (sources.size() == 0) {
//				//LOGGER.warn("cannot find any source for: " + OperatorTreePrinter.print(firstPattern));
//			}
//			
//			for (StatementPattern pattern : patternGroup) {
//				//System.out.println("Triple Pattern: " + pattern);
//			//System.out.println("Selected sources: " + sources);
//				QueryProcessingEval.totalTPsources =QueryProcessingEval.totalTPsources +sources.size();
//				pMap.add(new MappedStatementPattern(pattern, sources));
//			}
//		}
		
		return pMap;
	}
	
}
