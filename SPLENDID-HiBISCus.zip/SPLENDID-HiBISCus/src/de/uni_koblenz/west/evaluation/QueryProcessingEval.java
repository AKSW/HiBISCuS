/*
 * This file is part of RDF Federator.
 * Copyright 2011 Olaf Goerlitz
 * 
 * RDF Federator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * RDF Federator is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with RDF Federator.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * RDF Federator uses libraries from the OpenRDF Sesame Project licensed 
 * under the Aduna BSD-style license. 
 */
package de.uni_koblenz.west.evaluation;

import static org.openrdf.query.QueryLanguage.SPARQL;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.aksw.simba.fedsum.FedSumConfig;
import org.aksw.sparql.query.algebra.helpers.BGPGroupGenerator;
import org.openrdf.query.MalformedQueryException;
import org.openrdf.query.QueryEvaluationException;
import org.openrdf.query.TupleQuery;
import org.openrdf.query.TupleQueryResult;
import org.openrdf.query.algebra.StatementPattern;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fluidops.fedx.FederationManager;
import com.fluidops.fedx.algebra.StatementSource;

import de.uni_koblenz.west.splendid.test.config.Configuration;
import de.uni_koblenz.west.splendid.test.config.ConfigurationException;
import de.uni_koblenz.west.splendid.test.config.Query;

/**
 * Evaluation of the query processing.
 * 
 * @author Olaf Goerlitz
 */
public class QueryProcessingEval {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QueryProcessingEval.class);
	//private static final String DEFAULT_CONFIG = "setup/fed-test.properties";
	public static long timeElapsed =0;
	public static int totalTPsources = 0 ;
	private static final String DEFAULT_CONFIG = "eval/federation-test.properties";
	public static HashMap<Integer, List<StatementPattern>> DNFgrps = new  HashMap<Integer, List<StatementPattern>>();
	public static String strQuery;
	public static Map<StatementPattern, List<StatementSource>> stmtToSourcesMap = new HashMap<StatementPattern, List<StatementSource>> (); 
	public static boolean isFedSumSrcPerformed = false;
	public static BufferedWriter bw ;
	
	public static void main(String[] args) throws Exception {
		bw= new BufferedWriter(new FileWriter("spl_fedsum_results.txt",true));
		//--- FedSum Configureation -------------
		long strtTime = System.currentTimeMillis();
		String FedSummaries = "summaries\\FedSumFedBench.n3";
		
		String mode = "Index_dominant";  //{ASK_dominant, Index_dominant}
		double commonPredThreshold = 0.33 ;  //considered a predicate as common predicate if it is presenet in 33% available data sources

		FedSumConfig.initialize(FedSummaries,mode,commonPredThreshold);  // must call this function only one time at the start to load configuration information. Please specify the FedSum mode. 
		LOGGER.info("One time configuration loading time : "+ (System.currentTimeMillis()-strtTime));

			//---------------------------------------
		
		String configFile;
		
		// assign configuration file
		if (args.length == 0) {
			configFile = DEFAULT_CONFIG;
			LOGGER.info("using default config: " + configFile);
		} else {
			configFile = args[0];
			LOGGER.info("using config: " + configFile);
		}
		
		// initialize configuration and repository
		Repository repository = null;
		Iterator<Query> queries = null;
		try {
			Configuration config = Configuration.load(configFile);
			repository = config.createRepository();
			queries = config.getQueryIterator();
		} catch (IOException e) {
			LOGGER.error("cannot load test config: " + e.getMessage());
		} catch (ConfigurationException e) {
			LOGGER.error("failed to create repository: " + e.getMessage());
		}
		
		// execute all queries . Note this looping does not give the 100% accurate runtimes. We have created a new folder "onequery" within eval folder and run each query from there. 
		while (queries.hasNext()) {
			Query query = queries.next();
			
			LOGGER.info("next Query: " + query.getName());
//			bw.newLine();
//			bw.write("-------------"+query.getName()+"----------------");
//			bw.newLine();
			System.out.println(query.getQuery());
		    DNFgrps = BGPGroupGenerator.generateBgpGroups(query.getQuery());   // The time for DNF group generation is only around 5msec
        	try {
        		 
				RepositoryConnection con = repository.getConnection();
				
				try {
					
					TupleQuery tupleQuery = con.prepareTupleQuery(SPARQL, query.getQuery());

					//System.out.println(query.getQuery());
					long start = System.currentTimeMillis();
					TupleQueryResult result = tupleQuery.evaluate();
					
						//totalTPsources = 0 ;
					int count = 0;
					try {
////						// count elements of result set
						
						while (result.hasNext()) {
						result.next();
							count++;
					}
							long runtime = (System.currentTimeMillis() - start);
							System.out.println("\n ==>>:Query Execution Time = "+runtime+"\n");
							bw.write("\t"+(int) runtime);
							bw.newLine();
						System.out.println("Result Size: " + count);
					}
					finally {
						result.close();
						isFedSumSrcPerformed=false;
						//System.exit(0);
					}
					
				} catch (MalformedQueryException e) {
					LOGGER.error("malformed query:\n" + query, e);
					throw new IllegalArgumentException("Malformed query: ", e);
				} catch (QueryEvaluationException e) {
					LOGGER.error("failed to evaluate query on repository: " + repository + "\n" + query, e);
					Throwable cause = e.getCause();
					for (int i = 1; cause != null; cause = cause.getCause(), i++) {
						LOGGER.error("CAUSE " + i + ": " + cause);
					}
				}
			    finally {
			       con.close();
			     // Thread.sleep(1000);
			      
			    }
			} catch (RepositoryException e) {
				LOGGER.error("failed to open/close repository connection", e);
			}
		}
		
		try {
			bw.close();
			LOGGER.info("shutting down repository");
			repository.shutDown();
			LOGGER.info("shutdown complete");
			 FederationManager.getInstance().shutDown();
			 System.exit(0);
		} catch (RepositoryException e) {
			e.printStackTrace();
		}
		
	}

}
